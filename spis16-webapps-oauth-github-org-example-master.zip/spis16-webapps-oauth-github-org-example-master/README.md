# spis16-webapps-oauth-github-org-example 

Running on heroku at: <https://evening-earth-75796.herokuapp.com/>


Requires:

```
pip install --user Flask-OAuthlib
pip install --user PyGithub
```

The `--user` is only for ACMS accounts: leave off the `--user` if running on your own PC.
